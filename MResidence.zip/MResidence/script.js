$(document).ready(function () {


    // ========================================
    // MOBILE MENU
    // ========================================

    $("#menuButton").click(function () {

        $("#navigation").toggleClass("show");

    });


    $("#navigation a").click(function () {

        $("#navigation").removeClass("show");

    });



    // ========================================
    // WEATHER
    // ========================================

    $("#weatherButton").on("click", function () {

        console.log("Weather button clicked");


        $("#weatherResult").html(
            "<p>Loading current weather...</p>"
        );


        $.ajax({

            url: "https://api.open-meteo.com/v1/forecast",

            method: "GET",

            dataType: "json",

            data: {

                latitude: 9.9252,

                longitude: 78.1198,

                current:
                    "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m",

                timezone: "Asia/Kolkata"

            },


            success: function (data) {

                console.log("Weather API response:");
                console.log(data);


                var temperature =
                    data.current.temperature_2m;


                var humidity =
                    data.current.relative_humidity_2m;


                var feelsLike =
                    data.current.apparent_temperature;


                var windSpeed =
                    data.current.wind_speed_10m;


                $("#weatherResult").html(

                    "<h3>Current Weather in Madurai</h3>" +

                    "<div class='weather-data'>" +

                    "<div>" +
                    "<strong>" +
                    temperature +
                    "°C" +
                    "</strong>" +
                    "<span>Temperature</span>" +
                    "</div>" +

                    "<div>" +
                    "<strong>" +
                    humidity +
                    "%</strong>" +
                    "<span>Humidity</span>" +
                    "</div>" +

                    "<div>" +
                    "<strong>" +
                    feelsLike +
                    "°C" +
                    "</strong>" +
                    "<span>Feels Like</span>" +
                    "</div>" +

                    "<div>" +
                    "<strong>" +
                    windSpeed +
                    "</strong>" +
                    "<span>Wind km/h</span>" +
                    "</div>" +

                    "</div>"

                );

            },


            error: function (xhr, status, error) {

                console.log("Weather API Error");
                console.log("Status:", status);
                console.log("Error:", error);
                console.log("Response:", xhr.responseText);


                $("#weatherResult").html(

                    "<p>Unable to load weather.</p>" +

                    "<p>Please check your internet connection " +
                    "and try again.</p>"

                );

            }

        });

    });



    // ========================================
    // REGISTRATION FORM
    // ========================================

    $("#registrationForm").submit(function (event) {

        event.preventDefault();


        var name =
            $("#name").val().trim();


        var email =
            $("#email").val().trim();


        var phone =
            $("#phone").val().trim();


        var guests =
            $("#guests").val();


        var checkin =
            $("#checkin").val();


        var checkout =
            $("#checkout").val();


        var message =
            $("#message").val().trim();


        if (
            name === "" ||
            email === "" ||
            phone === "" ||
            checkin === "" ||
            checkout === ""
        ) {

            $("#registrationResult").html(
                "<p>Please fill in all required fields.</p>"
            );

            return;

        }


        if (checkout <= checkin) {

            $("#registrationResult").html(
                "<p>Check-out date must be after check-in date.</p>"
            );

            return;

        }


        $("#registrationResult").html(
            "<p>Submitting registration...</p>"
        );


        $.ajax({

            url: "https://jsonplaceholder.typicode.com/posts",

            method: "POST",

            data: {

                name: name,

                email: email,

                phone: phone,

                guests: guests,

                checkin: checkin,

                checkout: checkout,

                message: message

            },


            success: function () {

                $("#registrationResult").html(

                    "<p>Thank you, " +
                    name +
                    ". Your registration was submitted successfully.</p>"

                );


                $("#registrationForm")[0].reset();

            },


            error: function () {

                $("#registrationResult").html(

                    "<p>Registration failed. Please try again.</p>"

                );

            }

        });

    });



    // ========================================
    // CONTACT FORM
    // ========================================

    $("#contactForm").submit(function (event) {

        event.preventDefault();


        var name =
            $("#contactName").val().trim();


        var email =
            $("#contactEmail").val().trim();


        var message =
            $("#contactMessage").val().trim();


        if (
            name === "" ||
            email === "" ||
            message === ""
        ) {

            $("#contactResult").html(
                "<p>Please fill in all fields.</p>"
            );

            return;

        }


        $("#contactResult").html(
            "<p>Sending message...</p>"
        );


        $.ajax({

            url: "https://jsonplaceholder.typicode.com/posts",

            method: "POST",

            data: {

                name: name,

                email: email,

                message: message

            },


            success: function () {

                $("#contactResult").html(

                    "<p>Thank you. Your message has been sent.</p>"

                );


                $("#contactForm")[0].reset();

            },


            error: function () {

                $("#contactResult").html(

                    "<p>Message could not be sent.</p>"

                );

            }

        });

    });

});